Definition for the file lists:

Tweets.csv: original data for our project

Tweets_Updata.csv: data after some process including remove of un formaitted, null values.

wordbag.txt: negetive word bags extract from tweets.csv, it is for machine learning analysis purpose

1000.csv: Sample input matrix for machine learning which has only three class. (1000 records)

TweetsAll1000.csv: original input matrix (1000 records)

1.csv: libsvmfile converted from original input matrix with 12 class labels

2.csv: libsvmfile converted from original input matrix with 3 class labels